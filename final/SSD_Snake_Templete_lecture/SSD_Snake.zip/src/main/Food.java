package main;

import lib.Block;

public class Food extends Block{

    public Food(int x, int y) {
        super(x, y);
    }
}
